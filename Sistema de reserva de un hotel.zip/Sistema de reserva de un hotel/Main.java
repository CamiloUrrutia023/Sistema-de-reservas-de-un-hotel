import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class Main {
    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("=== Sistema de Reservas de Hotel ===");

        
        List<Habitacion> habitaciones = ingresarHabitaciones();

        
        for (Habitacion habitacion : habitaciones) {
            SistemaReservas.añadirHabitacion(habitacion);
        }

        
        List<Usuario> usuarios = ingresarUsuarios();
        
        if (!usuarios.isEmpty()) {
            Usuario usuario = usuarios.get(0);
            usuario.registrarse();
            usuario.iniciarSesion();

            Date fechaInicio = new Date();
            Date fechaFin = new Date(System.currentTimeMillis() + 3600000L * 24 * 3); // Fecha de fin 3 días después
            List<Habitacion> habitacionesDisponibles = usuario.buscarHabitaciones(fechaInicio, fechaFin);
            if (!habitacionesDisponibles.isEmpty()) {
                Habitacion habitacionSeleccionada = seleccionarHabitacion(habitacionesDisponibles);
                usuario.hacerReserva(habitacionSeleccionada, fechaInicio, fechaFin);
                System.out.println("\nReserva realizada exitosamente para " + habitacionSeleccionada.getTipo());
            } else {
                System.out.println("\nNo hay habitaciones disponibles para las fechas seleccionadas.");
            }

            Administrador admin = new Administrador("Admin", "admin@hotel.com", "contraseñaAdmin");
            List<Reserva> reservas = admin.verListaReservas();
            imprimirListaReservas(reservas);
        } else {
            System.out.println("No se ingresaron usuarios. El programa se cerrará.");
        }
    }

    private static List<Habitacion> ingresarHabitaciones() {
        System.out.println("\n=== Ingreso de Habitaciones ===");
        List<Habitacion> habitaciones = new ArrayList<>();
        while (true) {
            System.out.print("Ingrese el tipo de habitación (o 'fin' para terminar): ");
            String tipo = scanner.nextLine();
            if (tipo.equalsIgnoreCase("fin")) {
                break;
            }
            if (tipo.isEmpty()) {
                System.out.println("El tipo de habitación no puede estar vacío. Inténtelo de nuevo.");
                continue;
            }
            System.out.print("Ingrese el precio por noche: ");
            double precioNoche = scanner.nextDouble();
            scanner.nextLine(); // Consumir el salto de línea
            if (precioNoche <= 0) {
                System.out.println("El precio por noche debe ser un valor positivo. Inténtelo de nuevo.");
                continue;
            }
            System.out.print("Ingrese la capacidad máxima: ");
            int capacidadMaxima = scanner.nextInt();
            scanner.nextLine(); // Consumir el salto de línea
            if (capacidadMaxima <= 0) {
                System.out.println("La capacidad máxima debe ser un valor positivo. Inténtelo de nuevo.");
                continue;
            }
            System.out.print("Ingrese las comodidades separadas por comas: ");
            String comodidadesStr = scanner.nextLine();
            List<String> comodidades = new ArrayList<>(Arrays.asList(comodidadesStr.split(",")));
            if (comodidades.isEmpty()) {
                System.out.println("Debe ingresar al menos una comodidad. Inténtelo de nuevo.");
                continue;
            }
            int id = habitaciones.size() + 1;
            Habitacion habitacion = new Habitacion(id, tipo, precioNoche, capacidadMaxima, comodidades);
            habitaciones.add(habitacion);
            System.out.println("Habitación " + tipo + " agregada correctamente.");
        }
        return habitaciones;
    }

    private static List<Usuario> ingresarUsuarios() {
        System.out.println("\n=== Ingreso de Usuarios ===");
        List<Usuario> usuarios = new ArrayList<>();
        while (true) {
            System.out.print("Ingrese el nombre del usuario (o 'fin' para terminar): ");
            String nombre = scanner.nextLine();
            if (nombre.equalsIgnoreCase("fin")) {
                break;
            }
            if (nombre.isEmpty()) {
                System.out.println("El nombre del usuario no puede estar vacío. Inténtelo de nuevo.");
                continue;
            }
            System.out.print("Ingrese el email: ");
            String email = scanner.nextLine();
            if (email.isEmpty()) {
                System.out.println("El email no puede estar vacío. Inténtelo de nuevo.");
                continue;
            }
            System.out.print("Ingrese la contraseña: ");
            String contraseña = scanner.nextLine();
            if (contraseña.isEmpty()) {
                System.out.println("La contraseña no puede estar vacía. Inténtelo de nuevo.");
                continue;
            }
            Usuario usuario = new Usuario(nombre, email, contraseña);
            usuarios.add(usuario);
            System.out.println("Usuario " + nombre + " agregado correctamente.");
        }
        return usuarios;
    }

    private static Habitacion seleccionarHabitacion(List<Habitacion> habitaciones) {
        System.out.println("\n=== Selección de Habitación ===");
        for (int i = 0; i < habitaciones.size(); i++) {
            Habitacion habitacion = habitaciones.get(i);
            System.out.println((i + 1) + ". " + habitacion.getTipo() + " - Precio: $" + habitacion.getPrecioNoche() + " - Capacidad: " + habitacion.getCapacidadMaxima() + " - Comodidades: " + String.join(", ", habitacion.getComodidades()));
        }
        System.out.print("Ingrese el número de la habitación que desea seleccionar: ");
        int opcion = scanner.nextInt();
        scanner.nextLine(); // Consumir el salto de línea
        if (opcion >= 1 && opcion <= habitaciones.size()) {
            return habitaciones.get(opcion - 1);
        } else {
            System.out.println("Opción inválida. Se seleccionará la primera habitación disponible.");
            return habitaciones.get(0);
        }
    }

    private static void imprimirListaReservas(List<Reserva> reservas) {
        if (!reservas.isEmpty()) {
            System.out.println("\n=== Lista de Reservas ===");
            System.out.printf("%-10s %-20s %-15s %-15s %-15s%n", "ID", "Usuario", "Habitación", "Fecha Inicio", "Fecha Fin");
            System.out.println("----------------------------------------------------------------------");
            for (Reserva reserva : reservas) {
                System.out.printf("%-10d %-20s %-15s %-15s %-15s%n",
                        reserva.getId(),
                        reserva.getUsuario().getNombre(),
                        reserva.getHabitacion().getTipo(),
                        reserva.getFechaInicio(),
                        reserva.getFechaFin()
                );
            }
        } else {
            System.out.println("\nNo hay reservas actualmente.");
        }
    }
}