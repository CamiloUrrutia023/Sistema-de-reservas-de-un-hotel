import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class SistemaReservas {
    private static List<Usuario> usuarios = new ArrayList<>();
    private static List<Habitacion> habitaciones = new ArrayList<>();
    private static List<Reserva> reservas = new ArrayList<>();

    public static List<Habitacion> buscarHabitacionesDisponibles(Date fechaInicio, Date fechaFin) {
        List<Habitacion> disponibles = new ArrayList<>();
        for (Habitacion habitacion : habitaciones) {
            boolean estaDisponible = true;
            for (Reserva reserva : reservas) {
                if (reserva.getHabitacion() == habitacion &&
                    (fechaInicio.after(reserva.getFechaInicio()) && fechaInicio.before(reserva.getFechaFin()) ||
                     fechaFin.after(reserva.getFechaInicio()) && fechaFin.before(reserva.getFechaFin()))) {
                    estaDisponible = false;
                    break;
                }
            }
            if (estaDisponible) {
                disponibles.add(habitacion);
            }
        }
        return disponibles;
    }

    public static void hacerReserva(Reserva reserva) {
        reservas.add(reserva);
    }

    public static void cancelarReserva(Reserva reserva) {
        reservas.remove(reserva);
    }

    public static void añadirHabitacion(Habitacion habitacion) {
        habitaciones.add(habitacion);
    }

    public static void eliminarHabitacion(Habitacion habitacion) {
        habitaciones.remove(habitacion);
        
    }

    public static void modificarHabitacion(Habitacion habitacion, Object detalles) {
        
    }

    public static List<Reserva> verListaReservas() {
        return reservas;
    }

}