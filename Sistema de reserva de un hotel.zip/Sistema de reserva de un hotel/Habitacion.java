import java.util.List;

public class Habitacion {
    private int id;
    private String tipo;
    private double precioNoche;
    private int capacidadMaxima;
    private List<String> comodidades;

    public Habitacion(int id, String tipo, double precioNoche, int capacidadMaxima, List<String> comodidades) {
        this.id = id;
        this.tipo = tipo;
        this.precioNoche = precioNoche;
        this.capacidadMaxima = capacidadMaxima;
        this.comodidades = comodidades;
    }

    public int getId() {
        return id;
    }

    public String getTipo() {
        return tipo;
    }

    public double getPrecioNoche() {
        return precioNoche;
    }

    public int getCapacidadMaxima() {
        return capacidadMaxima;
    }

    public List<String> getComodidades() {
        return comodidades;
    }
}
