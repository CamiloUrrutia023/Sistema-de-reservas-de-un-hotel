import java.util.ArrayList;
import java.util.Date;
import java.util.List;


public class Usuario {
    private String nombre;
    private String email;
    private String contraseña;
    private List<Reserva> reservas;

    public Usuario(String nombre, String email, String contraseña) {
        this.nombre = nombre;
        this.email = email;
        this.contraseña = contraseña;
        this.reservas = new ArrayList<>();
    }

    public String getNombre() {
        return nombre;
    }

    public String getEmail() {
        return email;
    }

    public String getContraseña() {
        return contraseña;
    }

    public List<Reserva> getReservas() {
        return reservas;
    }

    public void registrarse() {
        
    }

    public void iniciarSesion() {
    
    }

    public List<Habitacion> buscarHabitaciones(Date fechaInicio, Date fechaFin) {
        return SistemaReservas.buscarHabitacionesDisponibles(fechaInicio, fechaFin);
    }

    public void hacerReserva(Habitacion habitacion, Date fechaInicio, Date fechaFin) {
        Reserva reserva = new Reserva(this, habitacion, fechaInicio, fechaFin);
        reservas.add(reserva);
        SistemaReservas.hacerReserva(reserva);
    }

    public void cancelarReserva(Reserva reserva) {
        reservas.remove(reserva);
        SistemaReservas.cancelarReserva(reserva);
    }

    public List<Reserva> verReservas() {
        return reservas;
    }
}