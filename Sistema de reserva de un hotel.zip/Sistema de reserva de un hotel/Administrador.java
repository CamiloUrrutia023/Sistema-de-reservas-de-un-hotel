import java.util.List;

public class Administrador {
    private String nombre;
    private String email;
    private String contraseña;

    public Administrador(String nombre, String email, String contraseña) {
        this.nombre = nombre;
        this.email = email;
        this.contraseña = contraseña;
    }

    public String getNombre() {
        return nombre;
    }

    public String getEmail() {
        return email;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void añadirHabitacion(Habitacion habitacion) {
        SistemaReservas.añadirHabitacion(habitacion);
    }

    public void eliminarHabitacion(Habitacion habitacion) {
        SistemaReservas.eliminarHabitacion(habitacion);
    }

    public void modificarHabitacion(Habitacion habitacion, Object detalles) {
        SistemaReservas.modificarHabitacion(habitacion, detalles);
    }

    public List<Reserva> verListaReservas() {
        return SistemaReservas.verListaReservas();
    }
}